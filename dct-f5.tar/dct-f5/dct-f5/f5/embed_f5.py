import numpy as np, sys, os, random
from PIL import Image

T = np.array([
    [0.3536, 0.3536, 0.3536, 0.3536, 0.3536, 0.3536, 0.3536, 0.3536],
    [0.4904, 0.4157, 0.2778, 0.0975,-0.0975,-0.2778,-0.4157,-0.4904],
    [0.4619, 0.1913,-0.1913,-0.4619,-0.4619,-0.1913, 0.1913, 0.4619],
    [0.4157,-0.0975,-0.4904,-0.2778, 0.2778, 0.4904, 0.0975,-0.4157],
    [0.3536,-0.3536,-0.3536, 0.3536, 0.3536,-0.3536,-0.3536, 0.3536],
    [0.2778,-0.4904, 0.0975, 0.4157,-0.4157,-0.0975, 0.4904,-0.2778],
    [0.1913,-0.4619, 0.4619,-0.1913,-0.1913, 0.4619,-0.4619, 0.1913],
    [0.0975,-0.2778, 0.4157,-0.4904, 0.4904,-0.4157, 0.2778,-0.0975]
])
Q_Y = np.array([
    [16,11,10,16,24,40,51,61],[12,12,14,19,26,58,60,55],
    [14,13,16,24,40,57,69,56],[14,17,22,29,51,87,80,62],
    [18,22,37,56,68,109,103,77],[24,35,55,64,81,104,113,92],
    [49,64,78,87,103,121,120,101],[72,92,95,98,112,100,103,99]
])

def msg_to_bits(msg):
    bits = []
    for ch in msg:
        for b in format(ord(ch), '08b'):
            bits.append(int(b))
    bits += [0]*8  # EOF marker
    return bits

def matrix_embed_123(h1, h2, h3, b1, b2):
    """
    Matrix embedding (1,2,3):
    Nhung 2 bit (b1,b2) vao 3 he so (h1,h2,h3)
    Chi thay doi toi da 1 he so
    Tra ve: (h1_new, h2_new, h3_new, so_he_so_thay_doi)
    """
    p1 = (h1 & 1) ^ (h2 & 1)  # XOR LSB cua h1 va h2
    p2 = (h2 & 1) ^ (h3 & 1)  # XOR LSB cua h2 va h3

    changed = 0
    if p1 == b1 and p2 == b2:
        # Khong can thay doi gi
        pass
    elif p1 != b1 and p2 == b2:
        # Chi thay doi h1
        h1 = h1 - 1 if h1 > 0 else h1 + 1
        changed = 1
    elif p1 == b1 and p2 != b2:
        # Chi thay doi h3
        h3 = h3 - 1 if h3 > 0 else h3 + 1
        changed = 1
    else:
        # Thay doi h2
        h2 = h2 - 1 if h2 > 0 else h2 + 1
        changed = 1

    return h1, h2, h3, changed

def embed(cover_path, msg, key):
    cover = np.array(Image.open(cover_path).convert("L"), dtype=np.float64)
    H, W = cover.shape
    bits = msg_to_bits(msg)
    total_bits = len(bits)

    # Lay tat ca he so DCT
    dct_blocks = {}
    for r in range(0, H-7, 8):
        for c in range(0, W-7, 8):
            block = cover[r:r+8, c:c+8]
            dct_b = np.dot(np.dot(T, block-128), T.T)
            q_b = np.round(dct_b / Q_Y).astype(int)
            dct_blocks[(r//8, c//8)] = q_b.copy()

    # Lay danh sach he so AC khac 0 va xao tron
    all_ac = []
    for (br, bc), q_b in dct_blocks.items():
        for i in range(8):
            for j in range(8):
                if i == 0 and j == 0:
                    continue
                if q_b[i][j] != 0:
                    all_ac.append((br, bc, i, j))

    random.seed(key)
    random.shuffle(all_ac)

    print(f"[INFO] Tin can nhung: '{msg}'")
    print(f"[INFO] Tong bits can nhung: {total_bits}")
    print(f"[INFO] He so AC co san: {len(all_ac)}")
    print(f"[INFO] He so can dung (nhom 3): {(total_bits//2)*3}")

    # Kiem tra du dung luong
    needed = ((total_bits + 1) // 2) * 3
    if needed > len(all_ac):
        print(f"[LOI] Khong du dung luong!")
        sys.exit(1)

    # Nhung tin bang matrix embedding
    bit_idx = 0
    ac_idx = 0
    shrinkage_count = 0
    changed_count = 0

    while bit_idx < total_bits - 1 and ac_idx + 2 < len(all_ac):
        b1 = bits[bit_idx]
        b2 = bits[bit_idx+1]

        # Lay 3 he so lien tiep
        br1,bc1,i1,j1 = all_ac[ac_idx]
        br2,bc2,i2,j2 = all_ac[ac_idx+1]
        br3,bc3,i3,j3 = all_ac[ac_idx+2]

        h1 = dct_blocks[(br1,bc1)][i1][j1]
        h2 = dct_blocks[(br2,bc2)][i2][j2]
        h3 = dct_blocks[(br3,bc3)][i3][j3]

        h1_new, h2_new, h3_new, changed = matrix_embed_123(h1, h2, h3, b1, b2)
        changed_count += changed

        # Xu ly shrinkage: neu he so thanh 0 thi bo qua
        def apply_with_shrinkage(block_dict, br, bc, i, j, old_val, new_val):
            nonlocal shrinkage_count
            if new_val == 0 and old_val != 0:
                shrinkage_count += 1
                return False  # Shrinkage xay ra
            block_dict[(br,bc)][i][j] = new_val
            return True

        apply_with_shrinkage(dct_blocks, br1,bc1,i1,j1, h1, h1_new)
        apply_with_shrinkage(dct_blocks, br2,bc2,i2,j2, h2, h2_new)
        apply_with_shrinkage(dct_blocks, br3,bc3,i3,j3, h3, h3_new)

        bit_idx += 2
        ac_idx += 3

    # Tai tao anh stego tu cac khoi DCT da sua
    stego = cover.copy()
    for (br, bc), q_b in dct_blocks.items():
        r, c = br*8, bc*8
        dct_back = q_b.astype(np.float64) * Q_Y
        stego[r:r+8, c:c+8] = np.clip(
            np.round(np.dot(np.dot(T.T, dct_back), T)) + 128, 0, 255)

    os.makedirs("output", exist_ok=True)
    Image.fromarray(stego.astype(np.uint8), mode='L').save("output/stego_f5.png")

    with open("output/embed_log.txt", 'w') as f:
        f.write(f"F5_DONE\n")
        f.write(f"message={msg}\n")
        f.write(f"key={key}\n")
        f.write(f"bits_embedded={bit_idx}\n")
        f.write(f"he_so_thay_doi={changed_count}\n")
        f.write(f"shrinkage={shrinkage_count}\n")

    print(f"\n[OK] Nhung Mini-F5 xong!")
    print(f"[OK] Bits da nhung   : {bit_idx}/{total_bits}")
    print(f"[OK] He so thay doi  : {changed_count}")
    print(f"[OK] Shrinkage xay ra: {shrinkage_count} lan")
    print(f"[OK] Anh stego       : output/stego_f5.png")

if __name__ == "__main__":
    if len(sys.argv) != 4:
        print("Cu phap: python3 embed_f5.py <cover.png> <message> <key>")
        print("Vi du:   python3 embed_f5.py cover.png F5TEST2024 F5KEY2024")
        sys.exit(1)
    embed(sys.argv[1], sys.argv[2], sys.argv[3])
