import numpy as np, math, os
from PIL import Image

T = np.array([
    [0.3536, 0.3536, 0.3536, 0.3536, 0.3536, 0.3536, 0.3536, 0.3536],
    [0.4904, 0.4157, 0.2778, 0.0975,-0.0975,-0.2778,-0.4157,-0.4904],
    [0.4619, 0.1913,-0.1913,-0.4619,-0.4619,-0.1913, 0.1913, 0.4619],
    [0.4157,-0.0975,-0.4904,-0.2778, 0.2778, 0.4904, 0.0975,-0.4157],
    [0.3536,-0.3536,-0.3536, 0.3536, 0.3536,-0.3536,-0.3536, 0.3536],
    [0.2778,-0.4904, 0.0975, 0.4157,-0.4157,-0.0975, 0.4904,-0.2778],
    [0.1913,-0.4619, 0.4619,-0.1913,-0.1913, 0.4619,-0.4619, 0.1913],
    [0.0975,-0.2778, 0.4157,-0.4904, 0.4904,-0.4157, 0.2778,-0.0975]
])
Q_Y = np.array([
    [16,11,10,16,24,40,51,61],[12,12,14,19,26,58,60,55],
    [14,13,16,24,40,57,69,56],[14,17,22,29,51,87,80,62],
    [18,22,37,56,68,109,103,77],[24,35,55,64,81,104,113,92],
    [49,64,78,87,103,121,120,101],[72,92,95,98,112,100,103,99]
])

def psnr(a, b):
    mse = np.mean((a.astype(float)-b.astype(float))**2)
    return 999.0 if mse == 0 else 20*math.log10(255.0/math.sqrt(mse))

def ssim(a, b):
    a, b = a.astype(float), b.astype(float)
    mu_a, mu_b = a.mean(), b.mean()
    c1, c2 = 6.5025, 58.5225
    sa = ((a-mu_a)**2).mean()
    sb = ((b-mu_b)**2).mean()
    sab = ((a-mu_a)*(b-mu_b)).mean()
    return ((2*mu_a*mu_b+c1)*(2*sab+c2))/((mu_a**2+mu_b**2+c1)*(sa+sb+c2))

def count_changed(img1, img2):
    return np.sum(img1 != img2)

def embed_lsb_dct(cover, msg):
    """LSB-DCT co dinh de so sanh"""
    bits = []
    for ch in msg:
        for b in format(ord(ch), '08b'):
            bits.append(int(b))
    bits += [0]*8
    H, W = cover.shape
    stego = cover.copy().astype(np.float64)
    bit_idx = 0
    for r in range(0, H-7, 8):
        for c in range(0, W-7, 8):
            if bit_idx >= len(bits): break
            block = cover[r:r+8,c:c+8].astype(np.float64)
            dct_b = np.dot(np.dot(T, block-128), T.T)
            q_b = np.round(dct_b/Q_Y).astype(int)
            q_b[7][7] = (q_b[7][7] & ~1) | bits[bit_idx]
            bit_idx += 1
            dct_back = q_b.astype(float)*Q_Y
            stego[r:r+8,c:c+8] = np.clip(
                np.round(np.dot(np.dot(T.T, dct_back), T))+128, 0, 255)
    return stego.astype(np.uint8)

cover  = np.array(Image.open("cover.png").convert("L"))
stego_f5 = np.array(Image.open("output/stego_f5.png").convert("L"))

msg = "F5TEST2024"
stego_lsb = embed_lsb_dct(cover.copy(), msg)

p_f5  = psnr(cover, stego_f5)
p_lsb = psnr(cover, stego_lsb)
s_f5  = ssim(cover, stego_f5)
s_lsb = ssim(cover, stego_lsb)
m_f5  = np.mean((cover.astype(float)-stego_f5.astype(float))**2)
m_lsb = np.mean((cover.astype(float)-stego_lsb.astype(float))**2)
c_f5  = count_changed(cover, stego_f5)
c_lsb = count_changed(cover, stego_lsb)

print("=" * 65)
print("  SO SANH: MINI-F5 vs LSB-DCT")
print("=" * 65)
print(f"{'Chi so':<25} {'Mini-F5':>18} {'LSB-DCT':>18}")
print("-" * 65)
print(f"{'PSNR (dB)':<25} {p_f5:>18.4f} {p_lsb:>18.4f}")
print(f"{'MSE':<25} {m_f5:>18.4f} {m_lsb:>18.4f}")
print(f"{'SSIM':<25} {s_f5:>18.6f} {s_lsb:>18.6f}")
print(f"{'Pixels thay doi':<25} {c_f5:>18d} {c_lsb:>18d}")
print("=" * 65)
print(f"\n-> Mini-F5 thay doi it pixel hon: {c_lsb - c_f5} pixel")
print(f"-> Mini-F5 PSNR cao hon        : {p_f5 - p_lsb:.4f} dB")
print(f"-> Mini-F5 kho bi phat hien hon!")

os.makedirs("output", exist_ok=True)
with open("output/compare_report.txt", "w") as f:
    f.write("SO SANH MINI-F5 vs LSB-DCT\n\n")
    f.write(f"PSNR Mini-F5 : {p_f5:.4f} dB\n")
    f.write(f"PSNR LSB-DCT : {p_lsb:.4f} dB\n")
    f.write(f"MSE  Mini-F5 : {m_f5:.4f}\n")
    f.write(f"MSE  LSB-DCT : {m_lsb:.4f}\n")
    f.write(f"SSIM Mini-F5 : {s_f5:.6f}\n")
    f.write(f"SSIM LSB-DCT : {s_lsb:.6f}\n")
    f.write(f"Pixels thay doi Mini-F5 : {c_f5}\n")
    f.write(f"Pixels thay doi LSB-DCT : {c_lsb}\n")
    f.write(f"\nKET LUAN:\n")
    f.write(f"Mini-F5 thay doi it pixel hon {c_lsb-c_f5} pixel\n")
    f.write(f"Mini-F5 PSNR cao hon {p_f5-p_lsb:.4f} dB\n")
    f.write(f"-> Mini-F5 chat luong tot hon va kho bi phat hien hon\n")
print(f"\n[OK] Bao cao: output/compare_report.txt")
