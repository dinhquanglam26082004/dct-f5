import numpy as np, sys, os, random
from PIL import Image

T = np.array([
    [0.3536, 0.3536, 0.3536, 0.3536, 0.3536, 0.3536, 0.3536, 0.3536],
    [0.4904, 0.4157, 0.2778, 0.0975,-0.0975,-0.2778,-0.4157,-0.4904],
    [0.4619, 0.1913,-0.1913,-0.4619,-0.4619,-0.1913, 0.1913, 0.4619],
    [0.4157,-0.0975,-0.4904,-0.2778, 0.2778, 0.4904, 0.0975,-0.4157],
    [0.3536,-0.3536,-0.3536, 0.3536, 0.3536,-0.3536,-0.3536, 0.3536],
    [0.2778,-0.4904, 0.0975, 0.4157,-0.4157,-0.0975, 0.4904,-0.2778],
    [0.1913,-0.4619, 0.4619,-0.1913,-0.1913, 0.4619,-0.4619, 0.1913],
    [0.0975,-0.2778, 0.4157,-0.4904, 0.4904,-0.4157, 0.2778,-0.0975]
])
Q_Y = np.array([
    [16,11,10,16,24,40,51,61],[12,12,14,19,26,58,60,55],
    [14,13,16,24,40,57,69,56],[14,17,22,29,51,87,80,62],
    [18,22,37,56,68,109,103,77],[24,35,55,64,81,104,113,92],
    [49,64,78,87,103,121,120,101],[72,92,95,98,112,100,103,99]
])

def extract(stego_path, key):
    stego = np.array(Image.open(stego_path).convert("L"), dtype=np.float64)
    H, W = stego.shape

    # Lay tat ca he so AC khac 0 va xao tron theo cung khoa
    all_ac = []
    dct_blocks = {}
    for r in range(0, H-7, 8):
        for c in range(0, W-7, 8):
            block = stego[r:r+8, c:c+8]
            dct_b = np.dot(np.dot(T, block-128), T.T)
            q_b = np.round(dct_b / Q_Y).astype(int)
            dct_blocks[(r//8, c//8)] = q_b
            for i in range(8):
                for j in range(8):
                    if i == 0 and j == 0:
                        continue
                    if q_b[i][j] != 0:
                        all_ac.append((r//8, c//8, i, j))

    # Xao tron theo cung khoa nhu khi nhung
    random.seed(key)
    random.shuffle(all_ac)

    # Trich xuat bits bang matrix decoding
    bits = []
    ac_idx = 0

    while ac_idx + 2 < len(all_ac):
        br1,bc1,i1,j1 = all_ac[ac_idx]
        br2,bc2,i2,j2 = all_ac[ac_idx+1]
        br3,bc3,i3,j3 = all_ac[ac_idx+2]

        h1 = dct_blocks[(br1,bc1)][i1][j1]
        h2 = dct_blocks[(br2,bc2)][i2][j2]
        h3 = dct_blocks[(br3,bc3)][i3][j3]

        # Giai ma: doc XOR LSB
        b1 = (h1 & 1) ^ (h2 & 1)
        b2 = (h2 & 1) ^ (h3 & 1)

        bits.append(b1)
        bits.append(b2)
        ac_idx += 3

        # Kiem tra EOF (8 bit 0 lien tiep)
        if len(bits) >= 8:
            last_8 = bits[-8:]
            if all(b == 0 for b in last_8):
                bits = bits[:-8]
                break

    # Chuyen bits -> text
    msg = ""
    for i in range(0, len(bits)-7, 8):
        byte = int(''.join(map(str, bits[i:i+8])), 2)
        if byte == 0:
            break
        msg += chr(byte)

    os.makedirs("output", exist_ok=True)
    with open("output/extract_log.txt", 'w') as f:
        f.write(f"EXTRACT_DONE\n")
        f.write(f"message={msg}\n")
        f.write(f"key={key}\n")
        f.write(f"bits_read={len(bits)}\n")

    print(f"[OK] Trich xuat Mini-F5 xong!")
    print(f"[OK] Tin giau: '{msg}'")
    print(f"[OK] Khoa: '{key}'")

if __name__ == "__main__":
    if len(sys.argv) != 3:
        print("Cu phap: python3 extract_f5.py <stego_f5.png> <key>")
        print("Vi du:   python3 extract_f5.py output/stego_f5.png F5KEY2024")
        sys.exit(1)
    extract(sys.argv[1], sys.argv[2])
