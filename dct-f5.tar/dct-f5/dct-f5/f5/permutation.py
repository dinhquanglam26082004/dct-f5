import numpy as np, sys, os, random

T = np.array([
    [0.3536, 0.3536, 0.3536, 0.3536, 0.3536, 0.3536, 0.3536, 0.3536],
    [0.4904, 0.4157, 0.2778, 0.0975,-0.0975,-0.2778,-0.4157,-0.4904],
    [0.4619, 0.1913,-0.1913,-0.4619,-0.4619,-0.1913, 0.1913, 0.4619],
    [0.4157,-0.0975,-0.4904,-0.2778, 0.2778, 0.4904, 0.0975,-0.4157],
    [0.3536,-0.3536,-0.3536, 0.3536, 0.3536,-0.3536,-0.3536, 0.3536],
    [0.2778,-0.4904, 0.0975, 0.4157,-0.4157,-0.0975, 0.4904,-0.2778],
    [0.1913,-0.4619, 0.4619,-0.1913,-0.1913, 0.4619,-0.4619, 0.1913],
    [0.0975,-0.2778, 0.4157,-0.4904, 0.4904,-0.4157, 0.2778,-0.0975]
])
Q_Y = np.array([
    [16,11,10,16,24,40,51,61],[12,12,14,19,26,58,60,55],
    [14,13,16,24,40,57,69,56],[14,17,22,29,51,87,80,62],
    [18,22,37,56,68,109,103,77],[24,35,55,64,81,104,113,92],
    [49,64,78,87,103,121,120,101],[72,92,95,98,112,100,103,99]
])

def get_ac_coefficients(img_array, key):
    """
    Lay tat ca he so AC tu anh, xao tron theo khoa
    Tra ve: danh sach (block_r, block_c, pi, pj, gia_tri)
    """
    H, W = img_array.shape
    all_ac = []

    for r in range(0, H-7, 8):
        for c in range(0, W-7, 8):
            block = img_array[r:r+8, c:c+8].astype(np.float64)
            dct_b = np.dot(np.dot(T, block-128), T.T)
            q_b = np.round(dct_b / Q_Y).astype(int)
            for i in range(8):
                for j in range(8):
                    if i == 0 and j == 0:
                        continue  # Bo qua DC
                    # Chi lay he so AC khac 0
                    if q_b[i][j] != 0:
                        all_ac.append((r//8, c//8, i, j, q_b[i][j]))

    # Xao tron theo khoa
    random.seed(key)
    random.shuffle(all_ac)

    print(f"[OK] Tong he so AC khac 0: {len(all_ac)}")
    print(f"[OK] Khoa su dung: '{key}'")
    print(f"[OK] Vi du 5 vi tri dau sau xao tron:")
    for idx, (br, bc, pi, pj, val) in enumerate(all_ac[:5]):
        print(f"     [{idx}] Khoi({br},{bc}) vi tri({pi},{pj}) = {val}")

    return all_ac

def save_permute_log(all_ac, key):
    os.makedirs("output", exist_ok=True)
    with open("output/permute_log.txt", 'w') as f:
        f.write(f"PERMUTE_DONE\n")
        f.write(f"key={key}\n")
        f.write(f"total_ac={len(all_ac)}\n")
        f.write(f"capacity_bits={len(all_ac)}\n")
        f.write(f"capacity_chars={len(all_ac)//8}\n")
    print(f"\n[OK] Log permutation: output/permute_log.txt")

if __name__ == "__main__":
    if len(sys.argv) != 3:
        print("Cu phap: python3 permutation.py <cover.png> <key>")
        print("Vi du:   python3 permutation.py cover.png F5KEY2024")
        sys.exit(1)
    from PIL import Image
    img = np.array(Image.open(sys.argv[1]).convert("L"))
    all_ac = get_ac_coefficients(img, sys.argv[2])
    save_permute_log(all_ac, sys.argv[2])
