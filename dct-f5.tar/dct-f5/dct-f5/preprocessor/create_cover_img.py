from PIL import Image
import numpy as np, sys

def create_cover(output="cover.png", size=(512, 512)):
    arr = np.zeros(size, dtype=np.uint8)
    for i in range(size[0]):
        for j in range(size[1]):
            arr[i][j] = int(128 + 60*np.sin(i*0.3)*np.cos(j*0.3)
                            + 30*np.sin(i*0.7+j*0.5)
                            + 20*np.cos(i*0.5-j*0.3))
    arr = np.clip(arr, 0, 255).astype(np.uint8)
    img = Image.fromarray(arr, mode='L')
    img.save(output)
    print(f"[OK] Tao anh bia: {output} ({size[0]}x{size[1]} pixel)")
    print(f"[OK] So khoi 8x8: {(size[0]//8)*(size[1]//8)}")
    print(f"[OK] So he so AC moi khoi: 63")
    print(f"[OK] Tong he so AC: {(size[0]//8)*(size[1]//8)*63}")

if __name__ == "__main__":
    out = sys.argv[1] if len(sys.argv) > 1 else "cover.png"
    create_cover(out)
