#!/bin/bash
mkdir -p /home/ubuntu/output
chmod +x /home/ubuntu/preprocessor/*.py 2>/dev/null
chmod +x /home/ubuntu/f5/*.py 2>/dev/null
chmod +x /home/ubuntu/extract/*.py 2>/dev/null
chmod +x /home/ubuntu/evaluate/*.py 2>/dev/null
